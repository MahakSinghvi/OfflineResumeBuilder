package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityProjectsBinding;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProjectsActivity extends RbBaseActivity {
    private String TAG = "ProjectsActivity";
    Context mContext;
    ActivityProjectsBinding binding;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;
    SessionManager sessionManager;
    private String MSG = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_projects);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_projects);
        initValues();
        clickEvents();
        //setdateclick();
    }
//    private void setdateclick() {
//        binding.etStartdate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                calendar = Calendar.getInstance();
//                year = calendar.get(Calendar.YEAR);
//                month = calendar.get(Calendar.MONTH);
//                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
//                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext,R.style.DialogTheme,
//                        new DatePickerDialog.OnDateSetListener() {
//                            @Override
//                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                                binding.etStartdate.setText(day + "/" + (month) + "/" + year);
//                            }
//                        }, year, month, dayOfMonth);
//                datePickerDialog.getDatePicker();
//                datePickerDialog.show();
//            }
//        });
//
//        binding.etEnddate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                calendar = Calendar.getInstance();
//                year = calendar.get(Calendar.YEAR);
//                month = calendar.get(Calendar.MONTH);
//                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
//                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext,R.style.DialogTheme,
//                        new DatePickerDialog.OnDateSetListener() {
//                            @Override
//                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                                binding.etEnddate.setText(day + "/" + (month + 1) + "/" + year);
//                            }
//                        }, year, month, dayOfMonth);
//                datePickerDialog.getDatePicker();
//                datePickerDialog.show();
//            }
//        });
//    }

    private void clickEvents() {
    binding.btnSave.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            checkEvents();
        }
    });
    binding.iconback.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            closeActivity();
            //finish();
        }
    });
    }

    private void checkEvents() {

        if(isETEmpty(binding.etTitle)){
            customToast("Enter Title ",200,1);
           // Toast.makeText(mContext,"Enter Title",Toast.LENGTH_SHORT).show();
        }
        else if(isETEmpty(binding.etdescript)){
            customToast("Enter description ",200,1);
            //Toast.makeText(mContext,"Enter description",Toast.LENGTH_SHORT).show();
        }
        else if(isETEmpty(binding.etDuration)){
            customToast("Enter duration ",200,1);
           // Toast.makeText(mContext,"Enter duration",Toast.LENGTH_SHORT).show();
        }
        else if(isETEmpty(binding.etTech)){
            customToast("Enter technology ",200,1);
           // Toast.makeText(mContext,"Enter technology",Toast.LENGTH_SHORT).show();
        }
        else if(isETEmpty(binding.etSize)){
            customToast("Enter team  size",200,1);
           // Toast.makeText(mContext,"Enter team size",Toast.LENGTH_SHORT).show();
        }
        else if(isETEmpty(binding.etUrl)){
            customToast("Enter website url",200,1);
            //.makeText(mContext,"Enter website url",Toast.LENGTH_SHORT).show();
        }
        else if(isETEmpty(binding.etLink)){
            customToast("Enter project link",200,1);
           // Toast.makeText(mContext,"Enter project link",Toast.LENGTH_SHORT).show();
        }
        else if(isETEmpty(binding.etRole)){
            customToast("Enter your role",200,1);
            //Toast.makeText(mContext,"Enter your role",Toast.LENGTH_SHORT).show();
        }
//        else if(isETEmpty(binding.etClient)){
//            Toast.makeText(mContext,"Enter Client name",Toast.LENGTH_SHORT).show();
//        }
//        else if(isETEmpty(binding.etStartdate)){
//            Toast.makeText(mContext,"Enter start date",Toast.LENGTH_SHORT).show();
//        }
//        else if(isETEmpty(binding.etEnddate)){
//            Toast.makeText(mContext,"Enter end date",Toast.LENGTH_SHORT).show();
//        }
        else {
            callProjectApi();
            //closeActivity();
        }
    }
    //project_title:Resume Builder
    //project_description:build the reume creator app
    //project_duration_time:3 months
    //project_technology:java
    //project_team_size:2
    //web_site_url:https://swchspacs.com/#/
    //project_link:https://swchspacs.com/#/
    //role_responsibility:developer
    //user_id:14

    private void callProjectApi() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "callProjectApi\t";
            HashMap<String, String> params = new HashMap<>();


            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());
            params.put("project_title", getETValue(binding.etTitle));
            params.put("project_description", getETValue(binding.etdescript));
            params.put("project_duration_time", getETValue(binding.etDuration));
            params.put("project_technology", getETValue(binding.etTech));
            params.put("project_team_size", getETValue(binding.etSize));
            params.put("web_site_url", getETValue(binding.etUrl));
            params.put("project_link", getETValue(binding.etLink));
            params.put("role_responsibility", getETValue(binding.etRole));



            Call<ResponseBody> call = apiService.projectDetailadd(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                customToast("Successfully Added",0,3);
                                closeActivity();

                            } else {
                                customToast(jsonObjectResult.getString("Error"),200,2);

                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, MSG + ": Exception\t\t" + e);
            dialogProgress.dismiss();
        }
    }

    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
        binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
    }
}