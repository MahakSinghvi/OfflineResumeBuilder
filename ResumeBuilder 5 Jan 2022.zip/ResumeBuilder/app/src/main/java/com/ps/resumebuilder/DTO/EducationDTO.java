package com.ps.resumebuilder.DTO;

public class EducationDTO {
//    String School,Year,Percentage;
//    int img;
//
//    public String getSchool() {
//        return School;
//    }
//
//    public String getYear() {
//        return Year;
//    }
//
//    public String getPercentage() {
//        return Percentage;
//    }
//
//    public int getImg() {
//        return img;
//    }
//
//    public EducationDTO(String school, String year, String percentage, int img) {
//        School = school;
//        Year = year;
//        Percentage = percentage;
//        this.img = img;
//    }

    String education_id;
    String degree;
    String univercity;
    String grade;
    String year;
    String level;

    public EducationDTO() {

    }

    public EducationDTO(String education_id, String degree, String univercity, String grade, String year, String level) {
        this.education_id = education_id;
        this.degree = degree;
        this.univercity = univercity;
        this.grade = grade;
        this.year = year;
        this.level = level;
    }

    public String getEducation_id() {
        return education_id;
    }

    public String getDegree() {
        return degree;
    }

    public String getUnivercity() {
        return univercity;
    }

    public String getGrade() {
        return grade;
    }

    public String getYear() {
        return year;
    }

    public String getLevel() {
        return level;
    }
}
