package com.ps.resumebuilder.DTO;

public class CreateDashboardDTO {
    String Title,btnOpen;
    int img;

    public String getBtnOpen() {
        return btnOpen;
    }

    public String getTitle() {
        return Title;
    }

    public int getImg() {
        return img;
    }

    public CreateDashboardDTO(String title, int img) {
        Title = title;
        this.img = img;
        this.btnOpen = btnOpen;
    }
}
