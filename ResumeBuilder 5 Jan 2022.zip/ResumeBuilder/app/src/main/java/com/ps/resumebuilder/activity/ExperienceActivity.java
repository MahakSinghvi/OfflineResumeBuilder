package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.github.dewinjm.monthyearpicker.MonthYearPickerDialog;
import com.github.dewinjm.monthyearpicker.MonthYearPickerDialogFragment;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityExperienceBinding;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ExperienceActivity extends RbBaseActivity {
    private String TAG = "ExperienceActivity";
    Context mContext;
    ActivityExperienceBinding binding;
    int yearSelected;
    int monthSelected;
    SessionManager sessionManager;
    public String MSG = " ";
    private static final String[] SKILLS = new String[]{
            "Full Time", "Part Time", "Self Employement", "Freelancer", "Internship", "Traniee"
    };
    //public static final String[] MONTHS = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_experience);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_experience);
        initValues();
        clickEvents();
        setdateclick();
        setmySkillsAdapter();
    }

    private void setmySkillsAdapter() {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.tv_entity, SKILLS);
        binding.acType.setAdapter(adapter);

    }

    private void setdateclick() {
        binding.etStartdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                yearSelected = calendar.get(Calendar.YEAR);
                monthSelected = calendar.get(Calendar.MONTH);


                MonthYearPickerDialogFragment dialogFragment = MonthYearPickerDialogFragment
                        .getInstance(monthSelected, yearSelected);

                dialogFragment.show(getSupportFragmentManager(), null);

                dialogFragment.setOnDateSetListener(new MonthYearPickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(int year, int monthOfYear) {
                        // do something
                        binding.etStartdate.setText(monthOfYear + "-" +year);
                    }

                });
            }
        });

        binding.etEnddate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                yearSelected = calendar.get(Calendar.YEAR);
                monthSelected = calendar.get(Calendar.MONTH);

                MonthYearPickerDialogFragment dialogFragment = MonthYearPickerDialogFragment
                        .getInstance(monthSelected, yearSelected);

                dialogFragment.show(getSupportFragmentManager(), null);

                dialogFragment.setOnDateSetListener(new MonthYearPickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(int year, int monthOfYear) {
                        // do something
                        binding.etEnddate.setText(monthOfYear + "-" +year);
                    }
                });
            }
        });
    }

    private void clickEvents() {
        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();

            }
        });
    }

    private void checkValidation() {

        if (isETEmpty(binding.etCompanyName)) {
            customToast("Enter Company name",200,1);
            //Toast.makeText(mContext, "Enter Company name", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etJobTitle)) {
            customToast("Enter Job Title",200,1);
            //Toast.makeText(mContext, "Enter company name", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etdescript)) {
            customToast("Enter job description",200,1);
            //Toast.makeText(mContext, "Enter job description", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etStartdate)) {
            customToast("Enter Start date",200,1);
            //Toast.makeText(mContext, "Enter Start date", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etEnddate)) {
            customToast("Enter End date",200,1);
           // Toast.makeText(mContext, "Enter End date", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etCurrentctc)) {
            customToast("Enter current ctc",200,1);
            //Toast.makeText(mContext, "Enter current ctc", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etRole)) {
            customToast("Enter job role",200,1);
            //Toast.makeText(mContext, "Enter job role", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etLocation)) {
            customToast("Enter job Location",200,1);
            //Toast.makeText(mContext, "Enter job Location", Toast.LENGTH_SHORT).show();
        } else {
            callExperienceApi();
            //closeActivity();
        }
    }

    private void callExperienceApi() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "callExperienceApi\t";
            HashMap<String, String> params = new HashMap<>();


            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());
            params.put("company_name", getETValue(binding.etCompanyName));
            params.put("job_title", getETValue(binding.etJobTitle));
            params.put("start_date", getETValue(binding.etStartdate));
            params.put("end_date", getETValue(binding.etEnddate));
            params.put("description", getETValue(binding.etdescript));
            params.put("current_ctc", getETValue(binding.etCurrentctc));
            params.put("role_responsibility", getETValue(binding.etRole));
            params.put("work_location", getETValue(binding.etLocation));
            params.put("total_experience", "1");
            params.put("user_resume_id", "3");
            params.put("emp_type", binding.acType.getText().toString().trim());


            Call<ResponseBody> call = apiService.experianceDetailadd(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                customToast("Successfully Added",0,3);
                                closeActivity();

                            } else {
                                customToast(jsonObjectResult.getString("Error"),200,2);
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, MSG + ": Exception\t\t" + e);
            dialogProgress.dismiss();
        }
    }

    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
        binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
    }
}