package com.ps.resumebuilder.activity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ps.resumebuilder.DTO.ExperienceDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.adapter.ExperinceAdapter;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.common.SwipeToDeleteCallback;
import com.ps.resumebuilder.databinding.ActivityAddExperienceBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddExperienceActivity extends RbBaseActivity {
    ActivityAddExperienceBinding binding;
    private String TAG = "AddExperienceActivity";
    Context mContext;
    ArrayList<ExperienceDTO> experienceDTOArrayList;
    ExperinceAdapter experinceAdapter;
    SessionManager sessionManager;
    public String MSG = " ";
    String experience_id = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_experience);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_experience);
        initValues();
        clickEvents();
        setMyRecycle();
        enableSwipeToDeleteAndUndo();
        //  getExperienceData();
          setArrayValues();
    }

    private void getExperienceData() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "getExperienceData\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("id", sessionManager.getUserDetail().getEmployee_id());
            //params.put("user_resume_id" ,"3");

            Call<ResponseBody> call = apiService.experianceDetailfetch(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                setApiData(jsonObjectResult);


                            } else {
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        }
                        if (experienceDTOArrayList.size() < 1) {
                            binding.imgNoData.setVisibility(View.VISIBLE);
                        } else {
                            binding.imgNoData.setVisibility(View.GONE);
                            dialogProgress.dismiss();
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, "getEducationData: " + e);
            dialogProgress.dismiss();
        }
    }

    private void setApiData(JSONObject jsonObjectResult) {
        try {
            experienceDTOArrayList.clear();
            JSONArray jsonArray = jsonObjectResult.getJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                ExperienceDTO experienceDTO = new ExperienceDTO(
                        jsonObject.has("experience_id") ? jsonObject.getString("experience_id") : "",
                        jsonObject.has("user_id") ? jsonObject.getString("user_id") : "",
                        jsonObject.has("user_resume_id") ? jsonObject.getString("user_resume_id") : "0",
                        jsonObject.has("company_name") ? jsonObject.getString("company_name") : "",
                        jsonObject.has("job_title") ? jsonObject.getString("job_title") : "",
                        jsonObject.has("start_date") ? jsonObject.getString("start_date") : "",
                        jsonObject.has("end_date") ? jsonObject.getString("end_date") : "",
                        jsonObject.has("description") ? jsonObject.getString("description") : "",
                        jsonObject.has("current_ctc") ? jsonObject.getString("current_ctc") : "",
                        jsonObject.has("role_responsibility") ? jsonObject.getString("role_responsibility") : "",
                        jsonObject.has("emp_type") ? jsonObject.getString("emp_type") : "",
                        jsonObject.has("work_location") ? jsonObject.getString("work_location") : "",
                        jsonObject.has("total_experience") ? jsonObject.getString("total_experience") : "",
                        jsonObject.has("created") ? jsonObject.getString("created") : ""

                );
                experienceDTOArrayList.add(experienceDTO);
            }
            if (experinceAdapter != null) {
                experinceAdapter.notifyDataSetChanged();
            }

        } catch (Exception e) {
            Log.d(TAG, "setApiData: " + e);
        }


    }

    private void setArrayValues() {
        experienceDTOArrayList.clear();
        ExperienceDTO experienceDTO = new ExperienceDTO("01",sessionManager.getUserDetail().getEmployee_id(),"01","","Sr.Android Developer", "Parkhya Solutions pvt.ltd", "May 2014 - Aug 2015", "Full-Time", "", "", "", "", "", "");
        ExperienceDTO experienceDTO1 = new ExperienceDTO("01",sessionManager.getUserDetail().getEmployee_id(),"01","","Sr.Android Developer", "Parkhya Solutions pvt.ltd", "May 2014 - Aug 2015", "Full-Time", "", "", "", "", "", "");
        ExperienceDTO experienceDTO2= new ExperienceDTO("01",sessionManager.getUserDetail().getEmployee_id(),"01","","Sr.Android Developer", "Parkhya Solutions pvt.ltd", "May 2014 - Aug 2015", "Full-Time", "", "", "", "", "", "");
        ExperienceDTO experienceDTO3 = new ExperienceDTO("01",sessionManager.getUserDetail().getEmployee_id(),"01","","Sr.Android Developer", "Parkhya Solutions pvt.ltd", "May 2014 - Aug 2015", "Full-Time", "", "", "", "", "", "");
        ExperienceDTO experienceDTO4 = new ExperienceDTO("01",sessionManager.getUserDetail().getEmployee_id(),"01","","Sr.Android Developer", "Parkhya Solutions pvt.ltd", "May 2014 - Aug 2015", "Full-Time", "", "", "", "", "", "");

        experienceDTOArrayList.add(experienceDTO);
        experienceDTOArrayList.add(experienceDTO1);
        experienceDTOArrayList.add(experienceDTO2);
        experienceDTOArrayList.add(experienceDTO3);
        experienceDTOArrayList.add(experienceDTO4);

        if (experinceAdapter != null) {
            experinceAdapter.notifyDataSetChanged();
        }
    }

    private void setMyRecycle() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        experinceAdapter = new ExperinceAdapter(mContext, experienceDTOArrayList);
        binding.myrecycleExp.setLayoutManager(linearLayoutManager);
        binding.myrecycleExp.setAdapter(experinceAdapter);
    }

    private void clickEvents() {
        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity(ExperienceActivity.class);
            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });
    }

    private void initValues() {
        mContext = this;
        experienceDTOArrayList = new ArrayList<>();
        sessionManager = new SessionManager(mContext);
        binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
    }

    protected void onResume() {
        super.onResume();
//        getExperienceData();
    }

    private void enableSwipeToDeleteAndUndo() {
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(mContext) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                final int position = viewHolder.getAdapterPosition();
                showDeleteAlert(position);
//                educationAdapter.removeItem(position);

            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(binding.myrecycleExp);


    }

    private void showDeleteAlert(final int position) {
        final ExperienceDTO _modelNotificationAPI = experienceDTOArrayList.get(position);
        LayoutInflater factory = LayoutInflater.from(mContext);
        final View customView = factory.inflate(R.layout.popup_delete_alert, null);
        final android.app.AlertDialog optionDialog = new android.app.AlertDialog.Builder(mContext).create();
        optionDialog.getWindow().setGravity(Gravity.CENTER);
        optionDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        optionDialog.setView(customView);
        optionDialog.setCancelable(false);
        optionDialog.setCanceledOnTouchOutside(false);
        TextView pno_projectTitle, pno_degree, tv_pno_Yes, tv_pno_No;


        optionDialog.show();


        pno_projectTitle = customView.findViewById(R.id.pno_projectTitle);
        pno_degree = customView.findViewById(R.id.pno_degree);
        tv_pno_Yes = customView.findViewById(R.id.tv_pno_Yes);
        tv_pno_No = customView.findViewById(R.id.tv_pno_No);
        pno_projectTitle.setText("Do you want to Delete : " + _modelNotificationAPI.getJob_title());
        pno_degree.setText("Company Name : " + _modelNotificationAPI.getCompany_name());
//        pno_NotificationDate.setText(mContext.getString(R.string.stringNotificationProjectDate) + " : " + TenderAppBaseActivity.parseDateTime(_modelNotificationAPI.getCreated()));
        tv_pno_Yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    experience_id = _modelNotificationAPI.getExperience_id();
                    callDeleteNotificationAPI(position);

//                    educationAdapter.removeItem(position);
//
                    optionDialog.dismiss();
                } catch (Exception e) {
                    Log.d("Error", "==##==" + e);
                }
            }
        });

        tv_pno_No.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
//                    notificationAdapter.restoreItem(item, position);
                    experinceAdapter.notifyItemChanged(position);
                    optionDialog.dismiss();
                } catch (Exception e) {

                }
            }
        });

        Rect displayRectangle = new Rect();
        Window window = /*((Activity) mContext).*/
                getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(displayRectangle);
        optionDialog.getWindow().setLayout((int) (displayRectangle.width() *
                0.9f), optionDialog.getWindow().getAttributes().height);

    }

    private void callDeleteNotificationAPI(int position) {

        try {
            MSG = "callDeleteNotificationAPI\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("id", sessionManager.getUserDetail().getEmployee_id());
//                params.put("education_id",educationDTO.getEducation_id());
            params.put("experience_id", experience_id);

            Call<ResponseBody> call = apiService.experianceDetaildelete(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                experinceAdapter.removeItem(position);


                            } else {
                                customToast(jsonObjectResult.getString("message"), 200, 2);

                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                }
            });


        } catch (Exception e) {
            Log.d(TAG, "getExpereinceData: " + e);
        }

    }

}