package com.ps.resumebuilder.adapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ps.resumebuilder.DTO.ProjectDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.AdapterProjectBinding;

import java.util.ArrayList;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.ViewHolder> {
    private String TAG = "ProjectAdapter";
    Context mContext;
    private AdapterProjectBinding binding;
    RbBaseActivity baseActivity;
    LayoutInflater inflater;
    ArrayList<ProjectDTO> projectDTOArrayList;


    public ProjectAdapter(Context context,ArrayList<ProjectDTO> projectDTO) {
        this.mContext = context;
        baseActivity = (RbBaseActivity) mContext;
        inflater = LayoutInflater.from(mContext);
        projectDTOArrayList = projectDTO;
    }


    @NonNull
    @Override
    public ProjectAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(inflater, R.layout.adapter_project,parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ProjectAdapter.ViewHolder holder, int position) {
    holder._binding.tvProjectTitle.setText(projectDTOArrayList.get(position).getProject_title());
   // holder._binding.tvClientName.setText(projectDTOArrayList.get(position).getClient());
    holder._binding.tvPeriod.setText("Duration : "+projectDTOArrayList.get(position).getProject_duration_time());
    holder._binding.tvTechnology.setText("Technology : "+projectDTOArrayList.get(position).getProject_technology());
   // holder._binding.image1.setImageResource(projectDTOArrayList.get(position).getLogo());
    }

    @Override
    public int getItemCount() {
        return projectDTOArrayList.size();
    }

    public void removeItem(int position) {
        projectDTOArrayList
                .remove(position);
        notifyItemRemoved(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AdapterProjectBinding _binding;
        public ViewHolder(@NonNull AdapterProjectBinding binding) {
            super(binding.getRoot());
            this._binding = binding;
        }
    }
}