package com.ps.resumebuilder.DTO;

import androidx.annotation.NonNull;

public class SkillListDTO {
    String skill_master_id;
    String skill_name;
    String is_active;
    String created;
    String updated;

    public SkillListDTO(String skill_master_id, String skill_name, String is_active, String created, String updated) {
        this.skill_master_id = skill_master_id;
        this.skill_name = skill_name;
        this.is_active = is_active;
        this.created = created;
        this.updated = updated;
    }

    public String getSkill_master_id() {
        return skill_master_id;
    }

    public String getSkill_name() {
        return skill_name;
    }

    public String getIs_active() {
        return is_active;
    }

    public String getCreated() {
        return created;
    }

    public String getUpdated() {
        return updated;
    }

    @NonNull
    @Override
    public String toString() {
        return skill_name.toString();

    }


}
