package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.ps.resumebuilder.R;
import com.ps.resumebuilder.common.RbBaseActivity;

public class StartActivity extends RbBaseActivity {
    Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        initValues();
        delayScreen();

    }

    private void delayScreen() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                openActivity(WelcomeActivity.class);
                //Intent intent = new Intent(getApplicationContext(),WelcomeActivity.class);
                //startActivity(intent);
            }
        },2000);
    }

    private void initValues() {
    mContext = this;
    }
}