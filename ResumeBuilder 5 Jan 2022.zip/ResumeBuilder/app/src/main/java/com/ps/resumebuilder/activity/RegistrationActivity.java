package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.widget.Toast;

import com.ps.resumebuilder.R;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityRegistrationBinding;

import java.util.HashMap;

public class RegistrationActivity extends RbBaseActivity {
    Context mContext;
    private String TAG = "RegistrationActivity";
    ActivityRegistrationBinding binding;
    private String MSG = " ";
    Animation animation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_registration);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_registration);
        initValues();
        clickEvents();
    }

//    public void shakeItBaby() {
//        int DURATION = 500; // you can change this according to your need
//        if (Build.VERSION.SDK_INT >= 26) {
//            ((Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(VibrationEffect.createOneShot(DURATION, VibrationEffect.DEFAULT_AMPLITUDE));
//        } else {
//            ((Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(DURATION);
//        }
//    }

    private void clickEvents() {
    binding.btnRegister.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            checkValidations();
        }
    });
    binding.iconback.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            closeActivity();
            //finish();
        }
    });
    binding.tvLogin.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            openActivity(LoginActivity.class);
        }
    });
    }

    private void checkValidations() {

        if( isETEmpty(binding.etName)){
//            Animation scaleAnimation = new ScaleAnimation(0, -500, 1, 1);
//            scaleAnimation.setDuration(750);
//          //  scaleAnimation.setFillAfter(true);
           // binding.etName.startAnimation(scaleAnimation);
            customToast("Enter Name",200,1);
            //Toast.makeText(mContext,"Enter name",Toast.LENGTH_SHORT).show();
        }
        else if( isETEmpty(binding.etMobile)){
            customToast("Enter Mobile",200,1);
           // Toast.makeText(mContext,"Enter Mobile",Toast.LENGTH_SHORT).show();
        }
        else if( isETEmpty(binding.etEmail)){
            customToast("Enter Email",200,1);
            //Toast.makeText(mContext,"Enter Email",Toast.LENGTH_SHORT).show();
        }
        else if( isETEmpty(binding.etPassword)){
            customToast("Enter Password",200,1);
            //Toast.makeText(mContext,"Enter Password",Toast.LENGTH_SHORT).show();
        }
        else if( isETEmpty(binding.etRePassword)){
            customToast("Re-Enter Password",200,1);
            //Toast.makeText(mContext,"Renter Password",Toast.LENGTH_SHORT).show();
        }
        else if(!getETValue(binding.etPassword).equals(getETValue(binding.etRePassword))){
            binding.linearScreen.startAnimation(AnimationUtils.loadAnimation(mContext,R.anim.vibrate));
            customToast("Password Mismatched",200,1);
        //Toast.makeText(mContext,"Password Mismatched",Toast.LENGTH_SHORT).show();
       }
        else {
            customToast("Successfully Added",0,3);
            openActivity(LoginActivity.class);
        }
    }


    private void initValues() {
    mContext = this;
    animation = AnimationUtils.loadAnimation(this, R.anim.vibrate);
   // Animation vibrate = AnimationUtils.loadAnimation(this, R.anim.vibrate);

    }
}