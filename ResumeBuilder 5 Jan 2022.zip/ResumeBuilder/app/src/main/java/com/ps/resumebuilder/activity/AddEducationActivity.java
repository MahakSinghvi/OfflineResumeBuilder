package com.ps.resumebuilder.activity;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.ps.resumebuilder.DTO.EducationDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.adapter.EducationAdapter;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.common.SwipeToDeleteCallback;
import com.ps.resumebuilder.databinding.ActivityAddEducationBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddEducationActivity extends RbBaseActivity {
    ActivityAddEducationBinding binding;
    private String TAG = "AddEducationActivity";
    Context mContext;
    ArrayList<EducationDTO> educationDTOArrayList;
    EducationAdapter educationAdapter;
    SessionManager sessionManager;
    public String MSG = " ";
    String education_id = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_education);
        initValues();
        clickEvent();
        setMyRecycle();
        enableSwipeToDeleteAndUndo();
        setArrayListValues();
//        getEducationData();
    }

    public void getEducationData() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "getEducationData\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());

            Call<ResponseBody> call = apiService.educationDetailfetch(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                setApiData(jsonObjectResult);


                            } else {
                                customToast(jsonObjectResult.getString("message"),200,2);
                            }
                        }
                        if (educationDTOArrayList.size() < 1) {
                            binding.imgNoData.setVisibility(View.VISIBLE);
                        } else {
                            binding.imgNoData.setVisibility(View.GONE);
                            dialogProgress.dismiss();
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, "getEducationData: " + e);
            dialogProgress.dismiss();
        }
    }

    private void setApiData(JSONObject jsonObjectResult) {
        try {
            educationDTOArrayList.clear();
            JSONArray jsonArray = jsonObjectResult.getJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                EducationDTO educationDTO = new EducationDTO(
                        jsonObject.has("education_id") ? jsonObject.getString("education_id") : "",
                        jsonObject.has("degree") ? jsonObject.getString("degree") : "",
                        jsonObject.has("univercity") ? jsonObject.getString("univercity") : "",
                        jsonObject.has("grade") ? jsonObject.getString("grade") : "",
                        jsonObject.has("year") ? jsonObject.getString("year") : "",
                        jsonObject.has("level") ? jsonObject.getString("level") : ""
                );
                educationDTOArrayList.add(educationDTO);
            }
            if (educationAdapter != null) {
                educationAdapter.notifyDataSetChanged();
            }

        } catch (Exception e) {
            Log.d(TAG, "setApiData: " + e);
        }


    }

    private void setArrayListValues() {
        educationDTOArrayList.clear();
        EducationDTO educationDTO = new EducationDTO("01","10th","Shri Gujrati Samaj A.M.N.E.M School","A1", "2018", "78%");
        EducationDTO educationDTO1 = new EducationDTO("01","12th","Shri Gujrati Samaj A.M.N.E.M School","A2" ,"2018", "78%");
        EducationDTO educationDTO2 = new EducationDTO("01","12th","Shri Gujrati Samaj A.M.N.E.M School","A2" ,"2018", "78%");
        EducationDTO educationDTO3 = new EducationDTO("01","12th","Shri Gujrati Samaj A.M.N.E.M School","A2" ,"2018", "78%");
        EducationDTO educationDTO4 = new EducationDTO("01","12th","Shri Gujrati Samaj A.M.N.E.M School","A2" ,"2018", "78%");

        educationDTOArrayList.add(educationDTO);
        educationDTOArrayList.add(educationDTO1);
        educationDTOArrayList.add(educationDTO2);
        educationDTOArrayList.add(educationDTO3);
        educationDTOArrayList.add(educationDTO4);

        if (educationAdapter != null) {
            educationAdapter.notifyDataSetChanged();
        }

    }

    private void setMyRecycle() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        educationAdapter = new EducationAdapter(mContext, educationDTOArrayList);
        binding.myrecycle1.setLayoutManager(linearLayoutManager);
        binding.myrecycle1.setAdapter(educationAdapter);
    }

    private void clickEvent() {
        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity(EducationActivity.class);

            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });
    }

    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
        educationDTOArrayList = new ArrayList<>();
        binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
    }

    @Override
    protected void onResume() {
        super.onResume();
//        getEducationData();
    }

    private void enableSwipeToDeleteAndUndo() {
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(mContext) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                final int position = viewHolder.getAdapterPosition();
                showDeleteAlert(position);
//                educationAdapter.removeItem(position);

            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(binding.myrecycle1);

//        ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT | ItemTouchHelper.DOWN | ItemTouchHelper.UP) {
//
//            @Override
//            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
//                Toast.makeText(mContext, "on Move", Toast.LENGTH_SHORT).show();
//                return false;
//            }
//
//            @Override
//            public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {
//                Toast.makeText(mContext, "on Swiped ", Toast.LENGTH_SHORT).show();
//                //Remove swiped item from list and notify the RecyclerView
//                int position = viewHolder.getAdapterPosition();
//                educationDTOArrayList.remove(position);
//                educationAdapter.notifyDataSetChanged();
//
//            }
//        };
//
//        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
//        itemTouchHelper.attachToRecyclerView(binding.myrecycle1);


    }

    private void showDeleteAlert(final int position) {
        final EducationDTO _modelNotificationAPI = educationDTOArrayList.get(position);
        LayoutInflater factory = LayoutInflater.from(mContext);
        final View customView = factory.inflate(R.layout.popup_delete_alert, null);
        final android.app.AlertDialog optionDialog = new android.app.AlertDialog.Builder(mContext).create();
        optionDialog.getWindow().setGravity(Gravity.CENTER);
        optionDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        optionDialog.setView(customView);
        optionDialog.setCancelable(false);
        optionDialog.setCanceledOnTouchOutside(false);
        TextView pno_projectTitle, pno_degree, tv_pno_Yes, tv_pno_No;


        optionDialog.show();


        pno_projectTitle = customView.findViewById(R.id.pno_projectTitle);
        pno_degree = customView.findViewById(R.id.pno_degree);
        tv_pno_Yes = customView.findViewById(R.id.tv_pno_Yes);
        tv_pno_No = customView.findViewById(R.id.tv_pno_No);
        pno_projectTitle.setText("Do you want to Delete : "+_modelNotificationAPI.getUnivercity());
        pno_degree.setText("Degree : " + _modelNotificationAPI.getDegree());
//        pno_NotificationDate.setText(mContext.getString(R.string.stringNotificationProjectDate) + " : " + TenderAppBaseActivity.parseDateTime(_modelNotificationAPI.getCreated()));
        tv_pno_Yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    education_id = _modelNotificationAPI.getEducation_id();
                    callDeleteNotificationAPI(position);
//                    educationAdapter.removeItem(position);
//
                    optionDialog.dismiss();
                } catch (Exception e) {
                    Log.d("Error", "==##==" + e);
                }
            }
        });

        tv_pno_No.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
//                    notificationAdapter.restoreItem(item, position);
                    educationAdapter.notifyItemChanged(position);
                    optionDialog.dismiss();
                } catch (Exception e) {

                }
            }
        });

        Rect displayRectangle = new Rect();
        Window window = /*((Activity) mContext).*/
                getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(displayRectangle);
        optionDialog.getWindow().setLayout((int) (displayRectangle.width() *
                0.9f), optionDialog.getWindow().getAttributes().height);

    }

    private void callDeleteNotificationAPI(int position) {

            try {
                MSG = "callDeleteNotificationAPI\t";
                HashMap<String, String> params = new HashMap<>();
                params.put("user_id", sessionManager.getUserDetail().getEmployee_id());
//                params.put("education_id",educationDTO.getEducation_id());
                params.put("education_id",education_id);

                Call<ResponseBody> call = apiService.educationDetaildelete(params);
                Log.d(TAG, MSG + "params\t\t" + params);


                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        try {
                            if (response.isSuccessful()) {
                                String responseRecieved = response.body().string();

                                Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                                JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                                if (jsonObjectResult.getBoolean("status")) {
                                    educationAdapter.removeItem(position);


                                } else {
                                customToast(jsonObjectResult.getString("message"),200,2);

                                }
                            }

                        } catch (Exception e) {
                            Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    }
                });


            } catch (Exception e) {
                Log.d(TAG, "getEducationData: " + e);
            }

    }

}