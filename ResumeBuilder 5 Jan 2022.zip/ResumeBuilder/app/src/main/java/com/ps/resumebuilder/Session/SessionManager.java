package com.ps.resumebuilder.Session;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.ps.resumebuilder.DTO.UserInfoDTO;

public class SessionManager {
    private static  final String PREF_NAME_GLOBAL = "USER_ANDROID_DB_GLOBAL";
    int PRIVATE_MODE = 0;
    public SharedPreferences pref_globel ;
    public SharedPreferences.Editor editor_globel;

    Context mContext;
    String IS_LOGIN = "IsLogin";
    private static final String USER_DETAIL = "user_info";

    public SessionManager(Context context){
        mContext = context;
        pref_globel = mContext.getSharedPreferences(PREF_NAME_GLOBAL,PRIVATE_MODE);
        editor_globel = pref_globel.edit();
    }

    public boolean isLogin(){
        return pref_globel.getBoolean(IS_LOGIN,false);
    }

    public void setLogin(boolean vBool){
        editor_globel.putBoolean(IS_LOGIN,vBool);
        editor_globel.commit();
        editor_globel.apply();
    }

    public void setUserDetail(UserInfoDTO userDetail) {
        Gson gson = new Gson();
        String vLanDTO = gson.toJson(userDetail);
        editor_globel.putString(USER_DETAIL, vLanDTO);
        editor_globel.commit();
        editor_globel.apply();
    }

    public UserInfoDTO getUserDetail() {
        Gson gson = new Gson();
        String vjson = pref_globel.getString(USER_DETAIL, "");
        UserInfoDTO _userDTO = gson.fromJson(vjson, UserInfoDTO.class);
        return _userDTO;
    }

}
