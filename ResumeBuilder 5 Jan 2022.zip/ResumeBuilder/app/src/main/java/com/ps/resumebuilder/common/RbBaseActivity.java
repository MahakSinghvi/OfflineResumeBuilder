package com.ps.resumebuilder.common;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.DoubleBounce;
import com.github.ybq.android.spinkit.style.WanderingCubes;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.retrofit.ApiClient;
import com.ps.resumebuilder.retrofit.ApiInterface;

public abstract class RbBaseActivity extends AppCompatActivity {
    public String TAG = "RbBaseActivity";
    Context mContext;
    public ApiInterface apiService;
    public Animation shakeAnimation;
    public Dialog dialogProgress;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        initValues();

    }

    private void initValues() {
        mContext = this;
        apiService = ApiClient.getClient().create(ApiInterface.class);

    }

    //todo calling animation when entering form activity
    public void enterActivityAnimation() {
        overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
    }

    //todo calling animation when exit form activity
    public void exitActivityAnimation() {
        overridePendingTransition(R.anim.enter_from_left, R.anim.exit_to_right);
    }

    //todo calling animation when open activity form bottom to top
    public void openToTopAnimation() {
        overridePendingTransition(R.anim.slide_in_up, R.anim.nothing);
    }

    //todo calling animation when open activity form top to bottom
    public void closeToBottomAnimation() {
        overridePendingTransition(R.anim.nothing, R.anim.slide_out_up);
    }

//    public void vibrate(int duration, ViewGroup group) {
//        Vibrator vibs = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
//        vibs.vibrate(duration);
//        shakeAnim(group);
//    }
//
    public void shakeAnim(ViewGroup group) {
        Log.d(TAG, "shakeAnim: " + group);
        if (group != null)
            group.startAnimation(shakeAnimation);


    }
//
//    public void customToast(String msgPrint, int vibrateTime, ViewGroup group) {
//        Toast.makeText(mContext, msgPrint, Toast.LENGTH_LONG).show();
//        vibrate(vibrateTime, group);
//
//    }

    //todo calling custom toast
    public void customToast(String valueError, int duration, int colorNo) {
        new CustomToast().Show_Toast(mContext, getWindow().getDecorView().getRootView(),
                valueError,colorNo);
        if (duration > 0)
            vibrate(duration);

    }

    //todo for vibrating the device when  get error
    public void vibrate(int duration) {
        Vibrator vibs = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibs.vibrate(duration);
    }




    public boolean isETEmpty(EditText elementVal) {
        if (elementVal.getText().toString().trim().length() < 1) {
            return true;
        } else {
            return false;
        }
    }

    public String getETValue(EditText elementVal) {
        return elementVal.getText().toString().trim();
    }

    public String getTVValue(TextView elementVal) {
        return elementVal.getText().toString().trim();
    }


    //todo calling animation when open form activity
    public void openActivity(Class aClass) {
        startActivity(new Intent(mContext, aClass));
        enterActivityAnimation();
    }

    //todo calling animation when close form activity
    public void closeActivity() {
        finish();
        exitActivityAnimation();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        exitActivityAnimation();
    }
    public Dialog LoadingSpinner(Context mContext) {
        dialogProgress = new Dialog(mContext, android.R.style.Theme_Black);
        View _view = LayoutInflater.from(mContext).inflate(R.layout.custom_loader, null);
        dialogProgress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogProgress.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialogProgress.setContentView(_view);
        return dialogProgress;
    }
    public void load(){
        ProgressBar progressBar = (ProgressBar)findViewById(R.id.loader);
        Sprite doubleBounce = new WanderingCubes();
        progressBar.setIndeterminateDrawable(doubleBounce);

    }

}
