package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityWelcomeBinding;

public class WelcomeActivity extends RbBaseActivity {
    Context mContext;
    private String TAG = "WelcomeActivity";
    ActivityWelcomeBinding binding;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_welcome);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_welcome);
        initValues();
        clickEvents();
    }

    private void clickEvents() {
    binding.btnLogin.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            openActivity(LoginActivity.class);
//            Intent login = new Intent(mContext,LoginActivity.class);
//            startActivity(login);

        }
    });
    binding.btnRegister.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            openActivity(RegistrationActivity.class);
//            Intent register = new Intent(mContext,RegistrationActivity.class);
//            startActivity(register);
        }
    });
    }

    private void initValues() {
    mContext = this;
    sessionManager = new SessionManager(mContext);
    if(sessionManager.isLogin()){
        openActivity(DashboardActivity.class);
//        Intent intent = new Intent(mContext,DashboardActivity.class);
//        startActivity(intent);
    }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finishAffinity();
    }
}