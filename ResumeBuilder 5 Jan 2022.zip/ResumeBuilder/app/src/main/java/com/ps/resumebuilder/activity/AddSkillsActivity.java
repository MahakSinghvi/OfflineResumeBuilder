package com.ps.resumebuilder.activity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ps.resumebuilder.DTO.SkillDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.adapter.AdvancedAdapter;
import com.ps.resumebuilder.adapter.BeginnerAdapter;
import com.ps.resumebuilder.adapter.ExpertAdapter;
import com.ps.resumebuilder.adapter.IntermediateAdapter;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityAddSkillsBinding;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddSkillsActivity extends RbBaseActivity {
    ActivityAddSkillsBinding binding;
    Context mContext;
    private String TAG = "AddSkillsActivity";
    ArrayList<SkillDTO> advanceDTOArrayList;
    ArrayList<SkillDTO> expertDTOArrayList;
    ArrayList<SkillDTO> intermediateDTOArrayList;
    ArrayList<SkillDTO> beginnerDTOArrayList;
    ExpertAdapter expertAdapter;
    AdvancedAdapter advancedAdapter;
    IntermediateAdapter intermediateAdapter;
    BeginnerAdapter beginnerAdapter;
    SessionManager sessionManager;
    private String MSG = " ";
    String resume_skill_id = "";

    private static final String[] SKILLS = new String[]{
            "Java", "Javascript", "Json", "MongoBD", "Devops", "Data Analysis", "Go", "Larvel", ".Net", "Postgres", "Docker", "Kubernets",
            "MariaDB", "SQL", "Oracle", "Kotlin", "Flutter", "Data Entry", "BlockChain", "Internet Of Things", "Full Stack Developer",
            "Web Development", "Cloud Computing", "Big Query", "Artificial Intelligence", "Machine Learning", "Cyber Security",
            "Agile", "PHP", "Angular Js", "React Native", "React JS", "Microsoft Office"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_add_skills);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_skills);
//        resumeSkillId = new SkillDTO().getResume_skill_id();
        initValues();
        clickEvents();
        setMyRecycleExpert();
        setMyRecycleAdvanced();
        setMyIntermediate();
        setMyBeginner();
        setApiData(new JSONObject());
//        getSkillData();
        //onClickButtonTabs();
    }

//    private void onClickButtonTabs() {
//        //binding.btnExpert.set
//    binding.btnExpert.setOnClickListener(new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            binding.cardExpert.setVisibility(View.VISIBLE);
//            binding.cardAdv.setVisibility(View.GONE);
//            binding.cardInterm.setVisibility(View.GONE);
//            binding.cardBeg.setVisibility(View.GONE);
//        }
//    });
//        binding.btnAdvance.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                binding.cardExpert.setVisibility(View.GONE);
//                binding.cardAdv.setVisibility(View.VISIBLE);
//                binding.cardInterm.setVisibility(View.GONE);
//                binding.cardBeg.setVisibility(View.GONE);
//            }
//        });
//        binding.btnInterm.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                binding.cardExpert.setVisibility(View.GONE);
//                binding.cardAdv.setVisibility(View.GONE);
//                binding.cardInterm.setVisibility(View.VISIBLE);
//                binding.cardBeg.setVisibility(View.GONE);
//            }
//        });
//        binding.btnBeginner.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                binding.cardExpert.setVisibility(View.GONE);
//                binding.cardAdv.setVisibility(View.GONE);
//                binding.cardInterm.setVisibility(View.GONE);
//                binding.cardBeg.setVisibility(View.VISIBLE);
//            }
//        });
//    }


    private void getSkillData() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "getSkillData\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());

            Call<ResponseBody> call = apiService.resumeDetailfetch(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                setApiData(jsonObjectResult);


                            } else {

                                customToast(jsonObjectResult.getString("message"), 200, 2);

                            }
                        }
                        if (expertDTOArrayList.size() < 1) {
                            binding.imgNoData.setVisibility(View.VISIBLE);
                        } else {
                            binding.imgNoData.setVisibility(View.GONE);
                            dialogProgress.dismiss();
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, "getSkillData: " + e);
            dialogProgress.dismiss();
        }
    }

    private void setApiData(JSONObject jsonObjectResult) {
        try {
            expertDTOArrayList.clear();
            advanceDTOArrayList.clear();
            intermediateDTOArrayList.clear();
            beginnerDTOArrayList.clear();
            
            
            
           /* JSONArray jsonArray = jsonObjectResult.getJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                SkillDTO skillListDTO = new SkillDTO(
                        jsonObject.has("resume_skill_id") ? jsonObject.getString("resume_skill_id") : "",
                        jsonObject.has("user_id") ? jsonObject.getString("user_id") : "",
                        jsonObject.has("user_resume_id") ? jsonObject.getString("user_resume_id") : "",
                        jsonObject.has("resume_category_id") ? jsonObject.getString("resume_category_id") : "",
                        jsonObject.has("skill_master_id") ? jsonObject.getString("skill_master_id") : "",
                        jsonObject.has("skill_status") ? jsonObject.getString("skill_status") : "",
                        jsonObject.has("created") ? jsonObject.getString("created") : "",
                        jsonObject.has("updated") ? jsonObject.getString("updated") : "",
                        jsonObject.has("skill_name") ? jsonObject.getString("skill_name") : "",
                        jsonObject.has("category_id") ? jsonObject.getString("category_id") : "",
                        jsonObject.has("is_active") ? jsonObject.getString("is_active") : ""
                );
                if (jsonObject.getString("skill_status").equalsIgnoreCase("4")) {
                    expertDTOArrayList.add(skillListDTO);
                }
                if (jsonObject.getString("skill_status").equalsIgnoreCase("3")) {
                    advanceDTOArrayList.add(skillListDTO);
                }
                if (jsonObject.getString("skill_status").equalsIgnoreCase("2")) {
                    intermediateDTOArrayList.add(skillListDTO);
                }
                if (jsonObject.getString("skill_status").equalsIgnoreCase("1")) {
                    beginnerDTOArrayList.add(skillListDTO);
                }
            }*/

            for (int i = 0; i < SKILLS.length; i++) {
                SkillDTO skillListDTO = new SkillDTO("" + i, sessionManager.getUserDetail().getEmployee_id(), "" + (i + 1), "" + (i + 2),
                        "" + i, "", "", "", SKILLS[i], "" + (i + 3), "1");

                if (i < 5)
                    expertDTOArrayList.add(skillListDTO);
                if (i > 5 && advanceDTOArrayList.size() < 5)
                    advanceDTOArrayList.add(skillListDTO);
                if (i > 9 && intermediateDTOArrayList.size() < 5)
                intermediateDTOArrayList.add(skillListDTO);
                if (i > 13 && beginnerDTOArrayList.size() < 5)
                beginnerDTOArrayList.add(skillListDTO);


            }


            if (expertAdapter != null) {
                expertAdapter.notifyDataSetChanged();
            }
            if (advancedAdapter != null) {
                advancedAdapter.notifyDataSetChanged();

            }
            if (intermediateAdapter != null) {
                intermediateAdapter.notifyDataSetChanged();
            }
            if (beginnerAdapter != null) {
                beginnerAdapter.notifyDataSetChanged();
            }

        } catch (Exception e) {
            Log.d(TAG, "setApiData: " + e);
        }

    }

    private void setMyBeginner() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        beginnerAdapter = new BeginnerAdapter(mContext, beginnerDTOArrayList);
        binding.myrecycleBeginner.setLayoutManager(linearLayoutManager);
        binding.myrecycleBeginner.setAdapter(beginnerAdapter);
    }

    private void setMyIntermediate() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        intermediateAdapter = new IntermediateAdapter(mContext, intermediateDTOArrayList);
        binding.myrecycleIntermediate.setLayoutManager(linearLayoutManager);
        binding.myrecycleIntermediate.setAdapter(intermediateAdapter);
    }

    private void setMyRecycleExpert() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        expertAdapter = new ExpertAdapter(mContext, expertDTOArrayList);
        binding.myrecycleExpert.setLayoutManager(linearLayoutManager);
        binding.myrecycleExpert.setAdapter(expertAdapter);
    }

    private void setMyRecycleAdvanced() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        advancedAdapter = new AdvancedAdapter(mContext, advanceDTOArrayList);
        binding.myrecycleAdvanced.setLayoutManager(linearLayoutManager);
        binding.myrecycleAdvanced.setAdapter(advancedAdapter);
    }


    private void clickEvents() {
        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity(SkillsActivity.class);
            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });
    }


    private void initValues() {
        mContext = this;
        advanceDTOArrayList = new ArrayList<>();
        expertDTOArrayList = new ArrayList<>();
        intermediateDTOArrayList = new ArrayList<>();
        beginnerDTOArrayList = new ArrayList<>();
        sessionManager = new SessionManager(mContext);
//        resume_skill_id = skillDTO.getResume_skill_id();

        binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
    }

    @Override
    protected void onResume() {
        super.onResume();
//        getSkillData();
    }


    private void showDeleteAlert(final int position) {
        final SkillDTO _modelNotificationAPI = expertDTOArrayList.get(position);
        resume_skill_id = _modelNotificationAPI.getResume_skill_id();
        // LayoutInflater factory = LayoutInflater.from(mContext);

    }

    public void callDeleteNotificationAPI(int position, String listType) {

        try {
            MSG = "callDeleteNotificationAPI\t";
            HashMap<String, String> params = new HashMap<>();

            if (listType.equalsIgnoreCase("Advance"))
                params.put("resume_skill_id", advanceDTOArrayList.get(position).getResume_skill_id());

            if (listType.equalsIgnoreCase("Beginner"))
                params.put("resume_skill_id", beginnerDTOArrayList.get(position).getResume_skill_id());

            if (listType.equalsIgnoreCase("Expert"))
                params.put("resume_skill_id", expertDTOArrayList.get(position).getResume_skill_id());

            if (listType.equalsIgnoreCase("Intermediate"))
                params.put("resume_skill_id", intermediateDTOArrayList.get(position).getResume_skill_id());


            Log.d(TAG, MSG + "params\t\t" + params);

            Call<ResponseBody> call = apiService.resumeDetaildelete(params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {

                                if (listType.equalsIgnoreCase("Advance")) {
                                    advanceDTOArrayList.remove(position);
                                    advancedAdapter.removeItem(position);

                                }

                                if (listType.equalsIgnoreCase("Beginner")) {
                                    beginnerDTOArrayList.remove(position);
                                    beginnerAdapter.removeItem(position);

                                }

                                if (listType.equalsIgnoreCase("Expert")) {
                                    expertDTOArrayList.remove(position);
                                    expertAdapter.removeItem(position);
                                }

                                if (listType.equalsIgnoreCase("Intermediate")) {
                                    intermediateDTOArrayList.remove(position);
                                    intermediateAdapter.removeItem(position);
                                }

                            } else {
                                customToast(jsonObjectResult.getString("message"), 200, 2);

                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                }
            });


        } catch (Exception e) {
            Log.d(TAG, "getSkillData: " + e);
        }

    }

}