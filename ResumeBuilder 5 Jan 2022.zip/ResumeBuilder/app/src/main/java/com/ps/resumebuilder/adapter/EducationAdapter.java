package com.ps.resumebuilder.adapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ps.resumebuilder.DTO.EducationDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.AdapterEducationBinding;

import java.util.ArrayList;

public class EducationAdapter extends RecyclerView.Adapter<EducationAdapter.ViewHolder> {
    private String TAG = "EducationAdapter";
    Context mContext;
    RbBaseActivity baseActivity;
    LayoutInflater inflater;
    private AdapterEducationBinding binding;
    ArrayList<EducationDTO> educationDTOArrayList;

    public EducationAdapter(Context context, ArrayList<EducationDTO> educationDTO) {
        this.mContext = context;
        inflater = LayoutInflater.from(mContext);
        educationDTOArrayList = educationDTO;
        baseActivity = (RbBaseActivity) mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(inflater, R.layout.adapter_education, parent, false);
        return new ViewHolder(binding);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder._binding.tvSchool.setText(educationDTOArrayList.get(position).getUnivercity());
        holder._binding.tvCourse.setText("Degree : " + educationDTOArrayList.get(position).getDegree());
        holder._binding.tvYear.setText("Year : " + educationDTOArrayList.get(position).getYear());
        holder._binding.tvPercentage.setText("Percentage/ Grade : " + educationDTOArrayList.get(position).getGrade());

        if (educationDTOArrayList.get(position).getLevel().contains("Class 10th")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder._binding.image1.setImageDrawable(mContext.getDrawable(R.drawable.img_10thclass));
            }
        }
        if (educationDTOArrayList.get(position).getLevel().contains("12th")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder._binding.image1.setImageDrawable(mContext.getDrawable(R.drawable.img_12thclass));
            }
        }
        if (educationDTOArrayList.get(position).getLevel().contains("Graduation")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder._binding.image1.setImageDrawable(mContext.getDrawable(R.drawable.img_graduations));
            }
        }
        if (educationDTOArrayList.get(position).getLevel().contains("Post")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder._binding.image1.setImageDrawable(mContext.getDrawable(R.drawable.img_postgraduations));
            }
        }
        if (educationDTOArrayList.get(position).getLevel().contains("Other")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder._binding.image1.setImageDrawable(mContext.getDrawable(R.drawable.img_others));
            }
        }


    }

    public void removeItem(int position) {
        educationDTOArrayList
                .remove(position);
        notifyItemRemoved(position);
    }

    @Override
    public int getItemCount() {
        return educationDTOArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AdapterEducationBinding _binding;

        public ViewHolder(@NonNull AdapterEducationBinding binding) {
            super(binding.getRoot());
            this._binding = binding;
        }
    }
}