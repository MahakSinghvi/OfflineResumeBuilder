package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;

import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityDashboardBinding;

public class DashboardActivity extends RbBaseActivity/*AppCompatActivity*/ {
    ActivityDashboardBinding binding;
    Context mContext;
    private String TAG = "DashboardActivity";
    Window window;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_dashboard);
        //window.requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_dashboard);
        initValues();
        clickEvents();
        getUserInfo();
    }

    private void clickEvents() {
        binding.btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity(CreateActivity.class);


            }
        });
        binding.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.setLogin(false);
                openActivity(LoginActivity.class);
            }
        });
    }

    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
    }

    private void getUserInfo() {
        String s = sessionManager.getUserDetail().getName();
        Log.d(TAG, "getUserInfo: " + s);
        String s1 = sessionManager.getUserDetail().getMobile_number();
        Log.d(TAG, "getUserInfo: " + s1);
        String s2 = sessionManager.getUserDetail(). getEmail_id();
        Log.d(TAG, "getUserInfo: " + s2);



    }
}