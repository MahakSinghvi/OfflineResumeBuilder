package com.ps.resumebuilder.adapter;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ps.resumebuilder.DTO.SkillDTO;
import com.ps.resumebuilder.DTO.SkillListDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.activity.AddSkillsActivity;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.AdapterSkillBinding;

import java.util.ArrayList;

public class ExpertAdapter extends RecyclerView.Adapter<ExpertAdapter.ViewHolder> {
private String TAG = "ExpertAdapter";
    Context mContext;
    LayoutInflater inflater;
    RbBaseActivity baseActivity;
    ArrayList<SkillDTO> skillDTOArrayList;
    private AdapterSkillBinding binding;
    AddSkillsActivity addSkillsActivity;

    public ExpertAdapter(Context context, ArrayList<SkillDTO> skillDTO) {
        this.mContext = context;
        inflater = LayoutInflater.from(mContext);
        baseActivity =  (RbBaseActivity) mContext;
        skillDTOArrayList = skillDTO;
        addSkillsActivity = (AddSkillsActivity) mContext;
    }


    @NonNull
    @Override
    public ExpertAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(inflater, R.layout.adapter_skill,parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpertAdapter.ViewHolder holder, int position) {
    //holder._binding.imgBullet.setImageResource(skillDTOArrayList.get(position).getBullet());

    holder._binding.tvProjectTitle.setText(skillDTOArrayList.get(position).getSkill_name());

//    holder._binding.imgCross.setImageResource(skillDTOArrayList.get(position).getCross());
        holder._binding.imgCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSkillsActivity.callDeleteNotificationAPI(position, "Expert");
                //skillDTOArrayList.remove(position);
//                notifyItemRemoved(position);
               // notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return skillDTOArrayList.size();
    }
    public void removeItem(int position) {
        skillDTOArrayList
                .remove(position);
        notifyItemRemoved(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AdapterSkillBinding _binding;
        public ViewHolder(@NonNull AdapterSkillBinding binding) {
            super(binding.getRoot());
            this._binding = binding;
        }
    }
}