package com.ps.resumebuilder.DTO;

public class UserInfoDTO {
    String employee_id;
    String name;
    String user_name;
    String email_id;
    String mobile_number;
    String address;
    String password;
    String created_at;
    String updated_at;

    public UserInfoDTO(String employee_id, String name, String user_name, String email_id,
                       String mobile_number, String address, String password, String created_at, String updated_at) {
        this.employee_id = employee_id;
        this.name = name;
        this.user_name = user_name;
        this.email_id = email_id;
        this.mobile_number = mobile_number;
        this.address = address;
        this.password = password;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    public UserInfoDTO() {

    }

    public String getEmployee_id() {
        return employee_id;
    }

    public String getName() {
        return name;
    }

    public String getUser_name() {
        return user_name;
    }

    public String getEmail_id() {
        return email_id;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public String getAddress() {
        return address;
    }

    public String getPassword() {
        return password;
    }

    public String getCreated_at() {
        return created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }
}
