package com.ps.resumebuilder.activity;

import androidx.databinding.DataBindingUtil;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.DoubleBounce;
import com.github.ybq.android.spinkit.style.WanderingCubes;
import com.ps.resumebuilder.DTO.UserInfoDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityPersonalDetailsBinding;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonalDetailsActivity extends RbBaseActivity {
    ActivityPersonalDetailsBinding binding;
    private String TAG = "PersonalDetailsActivity";
    Context mContext;
    private String MSG = " ";
    int year;
    int month;
    int dayOfMonth;
    SessionManager sessionManager;
    Calendar calendar;
    String id = "";
    private static  final String[] STATUS = new String[]{
           "Married", "Single","Divorced","Engaged","Widowed"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_personal_details);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_personal_details);
        initValues();
        clickEvents();
        datesetEvents();
//        getUserDataAPI();
        setMyStatusAdapter();

    }

    private void setMyStatusAdapter() {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.tv_entity, STATUS);
        binding.acStatus.setAdapter(adapter);

    }

    private void datesetEvents() {
        binding.etDob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext, R.style.DialogTheme,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                binding.etDob.setText(day + "/" + (month + 1) + "/" + year);
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });

    }


    private void clickEvents() {
        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidations();
            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
                //finish();
            }
        });
    }

    private void checkValidations() {

        if (isETEmpty(binding.etName)) {
            customToast("Enter Name",200,1);
           // Toast.makeText(mContext, "Enter Name", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etEmail)) {
            customToast("Enter Email",200,1);
           // Toast.makeText(mContext, "Enter Email", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etAddress)) {
            customToast("Enter Address",200,1);
            //Toast.makeText(mContext, "Enter Address", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etContact)) {
            customToast("Enter Contact number",200,1);
            //Toast.makeText(mContext, "Enter Contact number", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etNationality)) {
            customToast("Enter Nationality",200,1);
            //Toast.makeText(mContext, "Enter Nationality", Toast.LENGTH_SHORT).show();
        }
        else if (binding.acStatus.getText().toString().trim().length() < 1 ) {
            customToast("Enter Status",200,1);
           // Toast.makeText(mContext, "Enter Status", Toast.LENGTH_SHORT).show();
        }
        else if (isETEmpty(binding.etFathername)) {
            customToast("Enter Your Fathername",200,1);
            //Toast.makeText(mContext, "Enter Your Fathername", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etLinkedin)) {
            customToast("Enter Linkedin",200,1);
            //Toast.makeText(mContext, "Enter Linkedin", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etGit)) {
            customToast("Enter github",200,1);
            //Toast.makeText(mContext, "Enter github", Toast.LENGTH_SHORT).show();
        } else {
            //  closeActivity();
            callPersonalDetailApi();
        }
    }


    private void callPersonalDetailApi() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "callPersonalDetailApi\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("image", "");
            params.put("name", getETValue(binding.etName));
            params.put("email", getETValue(binding.etEmail));
            params.put("address", getETValue(binding.etAddress));
            params.put("contact", getETValue(binding.etContact));
            params.put("dob", getETValue(binding.etDob));
            params.put("nationality", getETValue(binding.etNationality));
            params.put("marital_status", binding.acStatus.getText().toString().trim());

            if (binding.radioMale.isChecked()) {
                params.put("gender", "Male");
            }
            if (binding.radioFemale.isChecked()) {
                params.put("gender", "Female");
            }
            if (!binding.radioMale.isChecked() & !binding.radioFemale.isChecked()) {
                params.put("gender", "other");
            }

            params.put("father_name", getETValue(binding.etFathername));
            params.put("linkedin", getETValue(binding.etLinkedin));
            params.put("github", getETValue(binding.etGit));
            params.put("eid", sessionManager.getUserDetail().getEmployee_id());
            if (!id.equals(""))
                params.put("id", id);


            Call<ResponseBody> call = apiService.personalDetailadd(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {

                                setSessionData(true);

                            } else {
                                customToast(jsonObjectResult.getString("Error"),200,2);
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                             dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                         dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, MSG + ": Exception\t\t" + e);
              dialogProgress.dismiss();
        }


    }

    private void setSessionData(boolean vBoo) {
        try {
            UserInfoDTO userInfoDTO = new UserInfoDTO();
            userInfoDTO.setEmployee_id(sessionManager.getUserDetail().getEmployee_id());
            userInfoDTO.setName(getETValue(binding.etName));
            userInfoDTO.setUser_name(getETValue(binding.etName));
            userInfoDTO.setEmail_id(getETValue(binding.etEmail));
            userInfoDTO.setMobile_number(getETValue(binding.etContact));
            userInfoDTO.setAddress(getETValue(binding.etAddress));
            sessionManager.setUserDetail(userInfoDTO);
            if (vBoo)
                closeActivity();

        } catch (Exception e) {
            Log.d(TAG, "setUserData: " + e);
        }
    }


    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);

        // Calendar myCalendar = Calendar.getInstance();
    }

    private void getUserDataAPI() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();

            MSG = "getUserDataAPI\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("id", sessionManager.getUserDetail().getEmployee_id());

            Call<ResponseBody> call = apiService.personalDetailfetch(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
//                            customToast("Successfully Added",0,3);
//                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                setApiData(jsonObjectResult);


                            } else {
                                customToast(jsonObjectResult.getString("Error"),200,2);
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, "getUserDataAPI: " + e);
            dialogProgress.dismiss();
        }
    }

    private void setApiData(JSONObject jsonObject) {
        try {
            JSONObject jsonData = jsonObject.getJSONObject("data");
            id = jsonData.has("id") ? jsonData.getString("id") : "0";
            binding.tvWelcome.setText(jsonData.has("name") ? "Hello " + jsonData.getString("name") : "Hello User");
            binding.etName.setText(jsonData.has("name") ? jsonData.getString("name") : "");
            binding.etEmail.setText(jsonData.has("email") ? jsonData.getString("email") : "");
            binding.etAddress.setText(jsonData.has("address") ? jsonData.getString("address") : "");
            binding.etContact.setText(jsonData.has("contact") ? jsonData.getString("contact") : "");
            binding.etDob.setText(jsonData.has("dob") ? jsonData.getString("dob") : "");
            binding.etNationality.setText(jsonData.has("nationality") ? jsonData.getString("nationality") : "");
            binding.acStatus.setText(jsonData.has("marital_status") ? jsonData.getString("marital_status") : "");
            if (jsonData.getString("gender").equalsIgnoreCase("Female")) {
                binding.radioFemale.setChecked(true);
            }
            if (jsonData.getString("gender").equalsIgnoreCase("Male")) {
                binding.radioMale.setChecked(true);
            }

            binding.etFathername.setText(jsonData.has("father_name") ? jsonData.getString("father_name") : "");
            binding.etLinkedin.setText(jsonData.has("linkedin") ? jsonData.getString("linkedin") : "");
            binding.etGit.setText(jsonData.has("github") ? jsonData.getString("github") : "");

            setSessionData(false);

        } catch (Exception e) {
            Log.d(TAG, "setApiData: " + e);
        }
    }
}