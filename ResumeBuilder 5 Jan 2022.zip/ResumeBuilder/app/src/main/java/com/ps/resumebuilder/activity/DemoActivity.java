package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import com.ps.resumebuilder.R;

import java.util.ArrayList;

public class DemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);
//        initUI();
    }

//    private void initUI()
//    {
//        //UI reference of textView
//        final AutoCompleteTextView customerAutoTV = findViewById(R.id.customerTextView);
//
//        // create list of customer
//        ArrayList<String> customerList = getCustomerList();
//
//        //Create adapter
//        ArrayAdapter<String> adapter = new ArrayAdapter<>(DemoActivity.this, android.R.layout.simple_spinner_item, customerList);
//
//        //Set adapter
//        customerAutoTV.setAdapter(adapter);
//
//        //submit button click event registration
//        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View view)
//            {
////                startActivityForResult(
////                        new Intent(
////                                Intent.ACTION_PICK,
////                                android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI
////                        ),
////                        GET_FROM_GALLERY
////                );
//            }
//        });
//    }

    private ArrayList<String> getCustomerList()
    {
        ArrayList<String> customers = new ArrayList<>();
        customers.add("James");
        customers.add("Mary");
        customers.add("Paul");
        customers.add("Michael");
        customers.add("William");
        customers.add("Daniel");
        customers.add("Thomas");
        customers.add("Sarah");
        customers.add("Sophia");
        return customers;
    }
}
