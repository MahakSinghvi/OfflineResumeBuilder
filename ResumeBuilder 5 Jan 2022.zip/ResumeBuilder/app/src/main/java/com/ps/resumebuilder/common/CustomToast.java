package com.ps.resumebuilder.common;


import android.content.Context;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ps.resumebuilder.R;

public class CustomToast {

    // Custom Toast Method
    // colorNo 1: Red, 2:  warning, 3 : Success
    public void Show_Toast(Context context, View view, String error, int colorNo) {

        // Layout Inflater for inflating custom view
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // inflate the layout over view
        View layout = inflater.inflate(R.layout.custom_toast,
                (ViewGroup) view.findViewById(R.id.toast_root));


        //TODO LOGIC FOR COLOR CHANGE
        RelativeLayout relativeLayout = layout.findViewById(R.id.toast_root);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (colorNo == 1)
                relativeLayout.setBackgroundColor(context.getColor(R.color.red));
            if (colorNo == 2)
                relativeLayout.setBackgroundColor(context.getColor(R.color.yellow));
            if (colorNo == 3)
                relativeLayout.setBackgroundColor(context.getColor(R.color.green));
        }
//        if(colorNo == 1)
//            relativeLayout.getResources().getDrawable(R.drawable.icon_tick);
//        if(colorNo == 2)
//            relativeLayout.getResources().getDrawable(R.drawable.icon_error);
//        if(colorNo == 3)
//            relativeLayout.getResources().getDrawable(R.drawable.icon_tick);

        // Get TextView id and set error
        TextView text = layout.findViewById(R.id.toast_error);
        text.setText(error);

        Toast toast = new Toast(context);// Get Toast Context
        toast.setGravity(Gravity.TOP | Gravity.FILL_HORIZONTAL, 0, 0);// Set
        // Toast
        // gravity
        // and
        // Fill
        // Horizoontal
        toast.setDuration(Toast.LENGTH_SHORT);// Set Duration
        //noinspection deprecation
        toast.setView(layout);// Set Custom View over toast

        toast.show();// Finally show toast
    }


}
