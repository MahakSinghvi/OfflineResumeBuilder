package com.ps.resumebuilder.retrofit;

import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {


    //"email_id
    //password"
    @FormUrlEncoded
    @POST("user")
    Call<ResponseBody> user(@FieldMap HashMap<String, String> hm);
//    Call<ResponseBody> user(@Field("email_id") String vEmail,
//                            @Field ("password") String vPassword);


    @FormUrlEncoded
    @POST("personalDetailadd")
    Call<ResponseBody> personalDetailadd (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("personalDetailfetch")
    Call<ResponseBody> personalDetailfetch (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("objectiveAdd")
    Call<ResponseBody> objectiveAdd (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("educationDetailadd")
    Call<ResponseBody> educationDetailadd (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("educationDetailfetch")
    Call<ResponseBody> educationDetailfetch (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("experianceDetailadd")
    Call<ResponseBody> experianceDetailadd (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("experianceDetailfetch")
    Call<ResponseBody> experianceDetailfetch (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("projectDetailadd")
    Call<ResponseBody> projectDetailadd (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("projectDetailfetch")
    Call<ResponseBody> projectDetailfetch (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("resumeDetailadd")
    Call<ResponseBody> resumeDetailadd (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("resumeDetailfetch")
    Call<ResponseBody> resumeDetailfetch (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("educationDetaildelete")
    Call<ResponseBody> educationDetaildelete (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("projectDetaildelete")
    Call<ResponseBody> projectDetaildelete (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("experianceDetaildelete")
    Call<ResponseBody> experianceDetaildelete (@FieldMap HashMap<String, String> hm);

    @FormUrlEncoded
    @POST("resumeDetaildelete")
    Call<ResponseBody> resumeDetaildelete (@FieldMap HashMap<String, String> hm);

//    @FormUrlEncoded
    @POST("getSkills")
    Call<ResponseBody> getSkills ();


}
