package com.ps.resumebuilder.activity;

import androidx.databinding.DataBindingUtil;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.ps.resumebuilder.DTO.UserInfoDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityLoginBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends RbBaseActivity {
    Context mContext;
    private String TAG = "LoginActivity";
    private String MSG = "";
    ActivityLoginBinding binding;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login);
        initValues();
        clickEvents();
    }

    private void clickEvents() {
        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidations();
            }
        });
        binding.tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go = new Intent(mContext, RegistrationActivity.class);
                startActivity(go);
                finish();
            }
        });
    }

    private void checkValidations() {

        if (isETEmpty(binding.etEmail)) {
//           Toast.makeText(mContext,"Enter Email",Toast.LENGTH_SHORT).show();
            customToast("Enter Email Id", 200, 1);
        } else if (isETEmpty(binding.etPassword)) {
//            Toast.makeText(mContext,"Enter Password",Toast.LENGTH_SHORT).show();
            customToast("Enter Password", 200, 1);
        } else {
            sessionManager.setLogin(true);
            UserInfoDTO userInfoDTO = new UserInfoDTO(
                    "01",
                    "Tester Kumar",
                    "TK",
                    "tester@mailinator.com",
                    "0123456789",
                    "tester street",
                    "123456",
                    "05/01/2022",
                    "05/01/2022"
            );
            sessionManager.setUserDetail(userInfoDTO);
            openActivity(DashboardActivity.class);
//            callLoginAPI();
        }
    }

    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
    }

    private void callLoginAPI() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "callLoginAPI\t\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("email_id", getETValue(binding.etEmail));
            params.put("password", getETValue(binding.etPassword));

            Call<ResponseBody> call = apiService.user(params);

            Log.d(TAG, MSG + "params\t\t" + params);

            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseReceived\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);

                            if (jsonObjectResult.getInt("status") == 1) {
                                dialogProgress.dismiss();
                                Log.d(TAG, MSG + "onResponse: " + jsonObjectResult.getInt("status"));
//
                                JSONArray jsonArray = jsonObjectResult.getJSONArray("user_data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    UserInfoDTO userInfoDTO = new UserInfoDTO(
                                            jsonObject.has("employee_id") ? jsonObject.getString("employee_id") : "",
                                            jsonObject.has("name") ? jsonObject.getString("name") : "",
                                            jsonObject.has("user_name") ? jsonObject.getString("user_name") : "",
                                            jsonObject.has("email_id") ? jsonObject.getString("email_id") : "",
                                            jsonObject.has("mobile_number") ? jsonObject.getString("mobile_number") : "",
                                            jsonObject.has("address") ? jsonObject.getString("address") : "",
                                            jsonObject.has("password") ? jsonObject.getString("password") : "",
                                            jsonObject.has("created_at") ? jsonObject.getString("created_at") : "",
                                            jsonObject.has("updated_at") ? jsonObject.getString("updated_at") : ""
                                    );
                                    sessionManager.setUserDetail(userInfoDTO);
                                }
                                sessionManager.setLogin(true);
                                customToast("Success", 0, 3);
                                openActivity(DashboardActivity.class);


                            } else {
                                customToast(jsonObjectResult.getString("message"), 200, 2);
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, MSG + ": Exception\t\t" + e);
            dialogProgress.dismiss();
        }
    }

    @Override
    public void onBackPressed() {
        int backpress = 0;
        backpress = backpress + 1;

        if (backpress < 1) {
            this.finish();
        }
        Intent intent = new Intent(mContext,WelcomeActivity.class);
        startActivity(intent);

        this.finishAffinity();

    }
}