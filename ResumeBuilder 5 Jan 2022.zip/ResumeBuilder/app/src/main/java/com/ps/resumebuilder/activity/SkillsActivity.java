package com.ps.resumebuilder.activity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.ps.resumebuilder.DTO.SkillListDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivitySkillsBinding;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SkillsActivity extends RbBaseActivity {
    private String TAG = "SkillsActivity";
    Context mContext;
    ActivitySkillsBinding binding;
    SessionManager sessionManager;
    private String MSG = " ";
    ArrayList<SkillListDTO> skillListDTOArrayList;
    String skillMasterId = "";
    ArrayAdapter<SkillListDTO> adapterSkill;
    private static final String[] SKILLS = new String[]{
            "Java", "Javascript", "Json", "MongoBD", "Devops", "Data Analysis", "Go", "Larvel", ".Net", "Postgres", "Docker", "Kubernets",
            "MariaDB", "SQL", "Oracle", "Kotlin", "Flutter", "Data Entry", "BlockChain", "Internet Of Things", "Full Stack Developer",
            "Web Development", "Cloud Computing", "Big Query", "Artificial Intelligence", "Machine Learning", "Cyber Security",
            "Agile", "PHP", "Angular Js", "React Native", "React JS", "Microsoft Office"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_skills);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_skills);
        initValues();
        setSkillsListAdapter();
        clickEvents();
//        getSkillListAPI();
        setSkillList(new JSONObject());
    }

    private void getSkillListAPI() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "getSkillListAPI";
            Call<ResponseBody> call = apiService.getSkills();
//            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getInt("status") == 1) {

                                setSkillList(jsonObjectResult);

                            } else {
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });

        } catch (Exception e) {
            Log.d(TAG, "getSkillListAPI: " + e);
            dialogProgress.dismiss();
        }
    }

    private void setSkillList(JSONObject jsonObjectResult) {
        try {
            skillListDTOArrayList.clear();
            SkillListDTO skillListDTO1 = new SkillListDTO("", "Select Skill", "", "", "");
            skillListDTOArrayList.add(skillListDTO1);

           /* JSONArray jsonArray = jsonObjectResult.getJSONArray("skill_master");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                SkillListDTO skillListDTO = new SkillListDTO(
                        jsonObject.has("skill_master_id") ? jsonObject.getString("skill_master_id") : "",
                        jsonObject.has("skill_name") ? jsonObject.getString("skill_name") : "",
                        jsonObject.has("is_active") ? jsonObject.getString("is_active") : "",
                        jsonObject.has("created") ? jsonObject.getString("created") : "",
                        jsonObject.has("updated") ? jsonObject.getString("updated") : ""
                );
                skillListDTOArrayList.add(skillListDTO);

            }*/

            for (int i = 0; i < SKILLS.length; i++) {
                SkillListDTO skillListDTO = new SkillListDTO(""+i, SKILLS[i], "1", "", "");
                skillListDTOArrayList.add(skillListDTO);
            }


            if (adapterSkill != null) {
                adapterSkill.notifyDataSetChanged();
            }
        } catch (Exception e) {
            Log.d(TAG, "setSkillList: " + e);
        }
    }


    private void setSkillsListAdapter() {

        adapterSkill = new ArrayAdapter<SkillListDTO>(mContext,
                android.R.layout.simple_list_item_1, skillListDTOArrayList);
        binding.searchableSpinner.setAdapter(adapterSkill);
        binding.searchableSpinner.setTitle("Select Skill");
        binding.searchableSpinner.setPositiveButton("OK");

    }

    private void clickEvents() {
        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
                //finish();
            }
        });

//        binding.searchableSpinner.setOnSearchTextChangedListener(new SearchableListDialog.OnSearchTextChanged() {
//            @Override
//            public void onSearchTextChanged(String strText) {
//                for (int i = 0; i < skillListDTOArrayList.size(); i++) {
//                    if (skillListDTOArrayList.get(i).getSkill_name().equalsIgnoreCase(strText)) {
//                        skillMasterId = skillListDTOArrayList.get(i).getSkill_master_id();
//                        Log.d(TAG, "onSearchTextChanged: " + skillMasterId);
//                        break;
//                    }
//                }
//            }
//        });

        binding.searchableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                skillMasterId = skillListDTOArrayList.get(position).getSkill_master_id();
                Log.d(TAG, "onItemSelected: " + skillMasterId);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void checkValidation() {
//        if (binding.searchableSpinner.toString().trim().length() < 1) {
//            Toast.makeText(mContext, "Enter your skills", Toast.LENGTH_SHORT).show();
//        } else {
//            callSkillApi();
//            // closeActivity();
//        }
        if (skillMasterId.equals("")) {
            customToast("Select your skills", 200, 1);
            Toast.makeText(mContext, "Select your skills", Toast.LENGTH_SHORT).show();
        } else {
            callSkillApi();
        }
    }

    private void callSkillApi() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "callPersonalDetailApi\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("skill_master_id", skillMasterId);
            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());

            // resume id ???

            if (binding.radioBeginner.isChecked()) {
                params.put("skill_status", "1");
            }
            if (binding.radioIntermediate.isChecked()) {
                params.put("skill_status", "2");
            }
            if (binding.radioAdvance.isChecked()) {
                params.put("skill_status", "3");
            }
            if (binding.radioExpert.isChecked()) {
                params.put("skill_status", "4");
            }

            Call<ResponseBody> call = apiService.resumeDetailadd(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                customToast("Successfully Added", 0, 3);
                                closeActivity();

                            } else {
                                customToast(jsonObjectResult.getString("Error"), 200, 2);

                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, MSG + ": Exception\t\t" + e);
            dialogProgress.dismiss();
        }
    }

    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
        binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
        skillListDTOArrayList = new ArrayList<>();
    }
}