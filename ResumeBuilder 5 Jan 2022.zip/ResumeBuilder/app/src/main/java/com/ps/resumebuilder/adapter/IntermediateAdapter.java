package com.ps.resumebuilder.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.ps.resumebuilder.DTO.SkillDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.activity.AddSkillsActivity;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.AdapterIntermediateBinding;

import java.util.ArrayList;

public class IntermediateAdapter extends RecyclerView.Adapter<IntermediateAdapter.ViewHolder> {
    private  String TAG ="IntermediateAdapter";
    private  String MSG =" ";
    Context mContext;
    LayoutInflater inflater;
    RbBaseActivity baseActivity;
    ArrayList<SkillDTO> skillDTOArrayList;
    AdapterIntermediateBinding binding;
    AddSkillsActivity addSkillsActivity;

    public IntermediateAdapter(Context mContext, ArrayList<SkillDTO> skillDTO) {
        this.mContext = mContext;
        inflater = LayoutInflater.from(mContext);
        baseActivity = (RbBaseActivity) mContext;
        skillDTOArrayList = skillDTO;
        addSkillsActivity = (AddSkillsActivity) mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(inflater, R.layout.adapter_intermediate,parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
    holder._binding.tvProjectTitle.setText(skillDTOArrayList.get(position).getSkill_name());
        holder._binding.imgCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSkillsActivity.callDeleteNotificationAPI(position,"Intermediate");
                //skillDTOArrayList.remove(position);
              //  notifyItemRemoved(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return skillDTOArrayList.size();
    }
    public void removeItem(int position) {
        skillDTOArrayList
                .remove(position);
        notifyItemRemoved(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AdapterIntermediateBinding _binding;
        public ViewHolder(@NonNull AdapterIntermediateBinding binding) {
            super(binding.getRoot());
            this._binding = binding;
        }
    }
}
