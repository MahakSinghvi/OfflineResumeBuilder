package com.ps.resumebuilder.adapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ps.resumebuilder.DTO.ExperienceDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.AdapterExperinceBinding;

import java.util.ArrayList;

public class ExperinceAdapter extends RecyclerView.Adapter<ExperinceAdapter.ViewHolder> {
    private String TAG = "ExperinceAdapter";
    Context mContext;
    RbBaseActivity baseActivity;
    LayoutInflater inflater;
    private AdapterExperinceBinding binding;
    ArrayList<ExperienceDTO> experienceDTOArrayList;

    public ExperinceAdapter(Context mContext, ArrayList<ExperienceDTO> experienceDTO) {
        this.mContext = mContext;
        inflater = LayoutInflater.from(mContext);
        experienceDTOArrayList = experienceDTO;
        baseActivity =  (RbBaseActivity) mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(inflater, R.layout.adapter_experince,parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
    holder._binding.tvPosition.setText(experienceDTOArrayList.get(position).getJob_title());
    holder._binding.tvCompname.setText("Company : "+experienceDTOArrayList.get(position).getCompany_name());
    holder._binding.tvEmptype.setText("Employment Type : "+experienceDTOArrayList.get(position).getEmp_type());
    holder._binding.tvStartDate.setText("Period : "+experienceDTOArrayList.get(position).getStart_date()+ " ");
    holder._binding.tvEndDate.setText("  "+experienceDTOArrayList.get(position).getEnd_date());
   // holder._binding.image1.setImageResource(experienceDTOArrayList.get(position).getLogo());
    }

    @Override
    public int getItemCount() {
        return experienceDTOArrayList.size();
    }

    public void removeItem(int position) {
        experienceDTOArrayList
                .remove(position);
        notifyItemRemoved(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AdapterExperinceBinding _binding;
        public ViewHolder(@NonNull AdapterExperinceBinding binding) {
            super(binding.getRoot());
            this._binding = binding;
        }
    }
}
