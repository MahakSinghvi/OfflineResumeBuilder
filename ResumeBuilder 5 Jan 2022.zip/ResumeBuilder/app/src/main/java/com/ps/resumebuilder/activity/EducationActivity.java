package com.ps.resumebuilder.activity;

import androidx.databinding.DataBindingUtil;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityEducationBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EducationActivity extends RbBaseActivity {
    private String TAG = "EducationActivity";
    Context mContext;
    ActivityEducationBinding binding;
    SessionManager sessionManager;
    public String MSG = " ";
    private static final String[] EDUCATION = new String[]{
            "Class 10th", "Class 12th", "Graduation", "Post Graduation", "Others"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_education);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_education);
        initValues();
        clickEvents();
        setMyEducationAdapter();
    }


    private void setMyEducationAdapter() {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.tv_entity, EDUCATION);
        binding.acSelect.setAdapter(adapter);
    }

    private void clickEvents() {
        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();
            }
        });
    }

    private void checkValidation() {

        if (isETEmpty(binding.etDegree)) {
            customToast("Enter your Degree",200,1);
           // Toast.makeText(mContext, "Enter your Degree", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etUniversity)) {
            customToast("Enter your University",200,1);
           // Toast.makeText(mContext, "Enter your University", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etScore)) {
            customToast("Enter your Score",200,1);
           // Toast.makeText(mContext, "Enter your Score", Toast.LENGTH_SHORT).show();
        } else if (isETEmpty(binding.etYear)) {
            customToast("Enter Year",200,1);
           // Toast.makeText(mContext, "Enter Year", Toast.LENGTH_SHORT).show();
        } else {
            callEducationApi(getJSONArray());
            // closeActivity();
        }
    }

    private JSONArray getJSONArray() {
        JSONArray jsonArray = new JSONArray();
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("degree", getETValue(binding.etDegree));
            jsonObject.put("univercity", getETValue(binding.etUniversity));
            jsonObject.put("grade", getETValue(binding.etScore));
            jsonObject.put("year", getETValue(binding.etYear));
            jsonObject.put("level", binding.acSelect.getText().toString().trim());
            jsonArray.put(jsonObject);
            Log.d(TAG, "getJSONArray: " + jsonObject.toString());
        } catch (Exception e) {
            Log.d(TAG, "getJSONArray: " + e);
        }
        return jsonArray;
    }

    private void callEducationApi(JSONArray jsonArray) {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "callObjectiveAPI\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());
            params.put("detail", jsonArray.toString());
            Call<ResponseBody> call = apiService.educationDetailadd(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                customToast("Successfully Added",0,3);
                                closeActivity();

                            } else {
                                customToast(jsonObjectResult.getString("Error"),200,2);
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, MSG + ": Exception\t\t" + e);
            dialogProgress.dismiss();
        }
    }


    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
        binding.tvWelcome.setText("Hello "+sessionManager.getUserDetail().getName());
    }
}