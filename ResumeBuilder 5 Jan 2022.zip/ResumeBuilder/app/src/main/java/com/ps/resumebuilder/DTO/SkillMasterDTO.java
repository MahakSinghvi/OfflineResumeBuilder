package com.ps.resumebuilder.DTO;

public class SkillMasterDTO {
   String user_id;
   String skill_master_id;
   String skill_status;
   String resume_skill_id;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getSkill_master_id() {
        return skill_master_id;
    }

    public void setSkill_master_id(String skill_master_id) {
        this.skill_master_id = skill_master_id;
    }

    public String getSkill_status() {
        return skill_status;
    }

    public void setSkill_status(String skill_status) {
        this.skill_status = skill_status;
    }

    public String getResume_skill_id() {
        return resume_skill_id;
    }

    public void setResume_skill_id(String resume_skill_id) {
        this.resume_skill_id = resume_skill_id;
    }

    public SkillMasterDTO(String user_id, String skill_master_id, String skill_status, String resume_skill_id) {
        this.user_id = user_id;
        this.skill_master_id = skill_master_id;
        this.skill_status = skill_status;
        this.resume_skill_id = resume_skill_id;
    }


}
