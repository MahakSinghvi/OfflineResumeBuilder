package com.ps.resumebuilder.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.ps.resumebuilder.DTO.SkillDTO;
import com.ps.resumebuilder.DTO.SkillListDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.activity.AddSkillsActivity;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.AdapterAdvancedBinding;
import com.ps.resumebuilder.databinding.AdapterSkillBinding;

import java.util.ArrayList;

public class AdvancedAdapter extends RecyclerView.Adapter<AdvancedAdapter.ViewHolder> {
    private String TAG = "AdvancedAdapter";
    Context mContext;
   // SessionManager sessionManager;
    private  String MSG = " ";
    ArrayList<SkillDTO> skillDTOArrayList;
    LayoutInflater inflater;
    private AdapterAdvancedBinding binding;
    RbBaseActivity baseActivity;
    AddSkillsActivity addSkillsActivity;

    public AdvancedAdapter(Context mContext,  ArrayList<SkillDTO> skillDTO) {
        this.mContext = mContext;
        skillDTOArrayList = skillDTO;
        inflater = LayoutInflater.from(mContext);
        baseActivity =  (RbBaseActivity) mContext;
        addSkillsActivity = (AddSkillsActivity) mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(inflater, R.layout.adapter_advanced,parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
//        holder._binding.imgBullet.setImageResource(skillDTOArrayList.get(position).getBullet());
        holder._binding.tvProjectTitle.setText(skillDTOArrayList.get(position).getSkill_name());
//        holder._binding.imgCross.setImageResource(skillDTOArrayList.get(position).getCross());
        holder._binding.imgCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (addSkillsActivity!=null){
                    addSkillsActivity.callDeleteNotificationAPI(position,"Advance");
//                    notifyItemRemoved(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return skillDTOArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AdapterAdvancedBinding _binding;
        public ViewHolder(@NonNull AdapterAdvancedBinding binding) {
            super(binding.getRoot());
            this._binding = binding;
        }
    }


    public void removeItem(int position) {
        skillDTOArrayList
                .remove(position);
        notifyItemRemoved(position);
    }
}
