package com.ps.resumebuilder.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.ps.resumebuilder.DTO.CreateDashboardDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.activity.AddEducationActivity;
import com.ps.resumebuilder.activity.AddExperienceActivity;
import com.ps.resumebuilder.activity.AddProjectsActivity;
import com.ps.resumebuilder.activity.AddSkillsActivity;
import com.ps.resumebuilder.activity.CreateActivity;
import com.ps.resumebuilder.activity.ObjectiveActivity;
import com.ps.resumebuilder.activity.PersonalDetailsActivity;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.AdapterCreateDashboardBinding;

import java.util.ArrayList;

public class CreateDashboardAdapter extends RecyclerView.Adapter<CreateDashboardAdapter.ViewHolder> {
    AdapterCreateDashboardBinding binding;
    Context mContext;
    private String TAG = "CreateDashboardAdapter";
    LayoutInflater inflater;
    ArrayList<CreateDashboardDTO> createDashboardDTOArrayList;
    RbBaseActivity baseActivity;

    public CreateDashboardAdapter(Context context, ArrayList<CreateDashboardDTO> createDashboardDTO) {
        this.mContext = context;
        inflater = LayoutInflater.from(mContext);
        createDashboardDTOArrayList = createDashboardDTO;
        baseActivity = (RbBaseActivity) mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(inflater, R.layout.adapter_create_dashboard, parent, false);
        return new ViewHolder(binding);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder._binding.tvTitle.setText(createDashboardDTOArrayList.get(position).getTitle());
        holder._binding.image1.setImageResource(createDashboardDTOArrayList.get(position).getImg());

        holder._binding.btnopen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Intent intent;
                switch (position) {
                    case 0:
                        baseActivity.openActivity(PersonalDetailsActivity.class);
//                        intent =  new Intent(mContext, ObjectiveActivity.class);
                        break;

                    case 1:
                        baseActivity.openActivity(ObjectiveActivity.class);
                        //    intent =  new Intent(mContext, PersonalDetailsActivity.class);
                        break;

                    case 2:
                        baseActivity.openActivity(AddEducationActivity.class);
                        // intent =  new Intent(mContext, AddEducationActivity.class);
                        break;

                    case 3:
                        baseActivity.openActivity(AddExperienceActivity.class);
                        //intent =  new Intent(mContext, AddExperienceActivity.class);
                        break;

                    case 4:
                        baseActivity.openActivity(AddProjectsActivity.class);
                        //intent =  new Intent(mContext, AddProjectsActivity.class);
                        break;

                    case 5:
                        baseActivity.openActivity(AddSkillsActivity.class);
                        //intent =  new Intent(mContext, AddSkillsActivity.class);
                        break;

                    default:
                        baseActivity.openActivity(CreateActivity.class);
                        //intent =  new Intent(mContext, CreateActivity.class);
                        break;
                }
//        mContext.startActivity(intent);


            }
        });


    }

    @Override
    public int getItemCount() {
        return createDashboardDTOArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AdapterCreateDashboardBinding _binding;

        public ViewHolder(@NonNull AdapterCreateDashboardBinding binding) {
            super(binding.getRoot());
            this._binding = binding;

        }
    }
}