package com.ps.resumebuilder.DTO;

public class ProjectDTO {
//    String Title,Period,Technology;
//    int logo;
//
//    public String getTitle() {
//        return Title;
//    }
//
////    public String getClient() {
////        return Client;
////    }
//
//    public String getPeriod() {
//        return Period;
//    }
//
//    public String getTechnology() {
//        return Technology;
//    }
//
//    public int getLogo() {
//        return logo;
//    }
//
//    public ProjectDTO(String title, String period, String technology, int logo) {
//        Title = title;
////        Client = client;
//        Period = period;
//        Technology = technology;
//        this.logo = logo;
//    }

  String project_title;
  String project_description;
  String project_duration_time;
  String project_technology;
  String project_team_size;
  String web_site_url;
  String project_link;
  String role_responsibility;
  String user_id;

    public String getProject_title() {
        return project_title;
    }

    public void setProject_title(String project_title) {
        this.project_title = project_title;
    }

    public String getProject_description() {
        return project_description;
    }

    public void setProject_description(String project_description) {
        this.project_description = project_description;
    }

    public String getProject_duration_time() {
        return project_duration_time;
    }

    public void setProject_duration_time(String project_duration_time) {
        this.project_duration_time = project_duration_time;
    }

    public String getProject_technology() {
        return project_technology;
    }

    public void setProject_technology(String project_technology) {
        this.project_technology = project_technology;
    }

    public String getProject_team_size() {
        return project_team_size;
    }

    public void setProject_team_size(String project_team_size) {
        this.project_team_size = project_team_size;
    }

    public String getWeb_site_url() {
        return web_site_url;
    }

    public void setWeb_site_url(String web_site_url) {
        this.web_site_url = web_site_url;
    }

    public String getProject_link() {
        return project_link;
    }

    public void setProject_link(String project_link) {
        this.project_link = project_link;
    }

    public String getRole_responsibility() {
        return role_responsibility;
    }

    public void setRole_responsibility(String role_responsibility) {
        this.role_responsibility = role_responsibility;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }




    public ProjectDTO(String project_title, String project_description, String project_duration_time, String project_technology, String project_team_size, String web_site_url, String project_link, String role_responsibility, String user_id) {
        this.project_title = project_title;
        this.project_description = project_description;
        this.project_duration_time = project_duration_time;
        this.project_technology = project_technology;
        this.project_team_size = project_team_size;
        this.web_site_url = web_site_url;
        this.project_link = project_link;
        this.role_responsibility = role_responsibility;
        this.user_id = user_id;
    }
}
