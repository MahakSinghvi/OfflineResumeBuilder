package com.ps.resumebuilder.DTO;

public class ExperienceDTO {
//    String Position,Companyname,Workingperiod,Emptype;
//    int logo;
//
//    public String getPosition() {
//        return Position;
//    }
//
//    public String getCompanyname() {
//        return Companyname;
//    }
//
//    public String getWorkingperiod() {
//        return Workingperiod;
//    }
//
//    public String getEmptype() {
//        return Emptype;
//    }
//
//    public int getLogo() {
//        return logo;
//    }
//
//    public ExperienceDTO(String position, String companyname, String workingperiod, String emptype, int logo) {
//        Position = position;
//        Companyname = companyname;
//        Workingperiod = workingperiod;
//        Emptype = emptype;
//        this.logo = logo;
//    }

    String experience_id;
    String user_id;
    String user_resume_id;
    String company_name;
    String job_title;
    String start_date;
    String end_date;
    String description;
    String current_ctc;
    String role_responsibility;
    String emp_type;
    String work_location;
    String total_experience;

    public String getExperience_id() {
        return experience_id;
    }

    public void setExperience_id(String experience_id) {
        this.experience_id = experience_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_resume_id() {
        return user_resume_id;
    }

    public void setUser_resume_id(String user_resume_id) {
        this.user_resume_id = user_resume_id;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getJob_title() {
        return job_title;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCurrent_ctc() {
        return current_ctc;
    }

    public void setCurrent_ctc(String current_ctc) {
        this.current_ctc = current_ctc;
    }

    public String getRole_responsibility() {
        return role_responsibility;
    }

    public void setRole_responsibility(String role_responsibility) {
        this.role_responsibility = role_responsibility;
    }

    public String getEmp_type() {
        return emp_type;
    }

    public void setEmp_type(String emp_type) {
        this.emp_type = emp_type;
    }

    public String getWork_location() {
        return work_location;
    }

    public void setWork_location(String work_location) {
        this.work_location = work_location;
    }

    public String getTotal_experience() {
        return total_experience;
    }

    public void setTotal_experience(String total_experience) {
        this.total_experience = total_experience;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    String created;

    public ExperienceDTO(String experience_id, String user_id, String user_resume_id,
                         String company_name, String job_title, String start_date,
                         String end_date, String description, String current_ctc,
                         String role_responsibility, String emp_type,
                         String work_location, String total_experience, String created) {
        this.experience_id = experience_id;
        this.user_id = user_id;
        this.user_resume_id = user_resume_id;
        this.company_name = company_name;
        this.job_title = job_title;
        this.start_date = start_date;
        this.end_date = end_date;
        this.description = description;
        this.current_ctc = current_ctc;
        this.role_responsibility = role_responsibility;
        this.emp_type = emp_type;
        this.work_location = work_location;
        this.total_experience = total_experience;
        this.created = created;
    }
}
