package com.ps.resumebuilder.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.ps.resumebuilder.DTO.UserInfoDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.Session.SessionManager;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityObjectiveBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ObjectiveActivity extends RbBaseActivity {
    private String TAG = "ObjectiveActivity";
    Context mContext;
    ActivityObjectiveBinding binding;
    SessionManager sessionManager;
    private String MSG = " ";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_objective);
        initValues();
        clickEvents();
        getObjectiveDataApi();

    }


    private void getObjectiveDataApi() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "getObjectiveDataApi\t";
            HashMap<String, String> params = new HashMap<>();
            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());

            Call<ResponseBody> call = apiService.objectiveAdd(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {

                                setApiData(jsonObjectResult);

                            } else {
//                                customToast(jsonObjectResult.getString("message"));
//                                vibrate(200);
                            }
                        } else {
                            Log.d(TAG, MSG + "response\t\t" + response.toString());
                            dialogProgress.dismiss();
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        e.printStackTrace();
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, "getObjectiveDataApi: " + e);
            dialogProgress.dismiss();
        }
    }

    private void setApiData(JSONObject jsonObject) {
        try {
            JSONObject jsonData = jsonObject.getJSONObject("data");
//            binding.tvWelcome.setText(jsonData.has("name") ? "Hello " + jsonData.getString("name") : "Hello User");
            binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
            binding.etObject.setText(jsonData.has("objective") ? jsonData.getString("objective") : "");
        } catch (JSONException e) {
            Log.d(TAG, "setApiData: " + e);
        }
    }


    private void clickEvents() {
        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeActivity();

            }
        });
    }

    private void checkValidation() {

        if (isETEmpty(binding.etObject)) {
            customToast("Enter your Objective",200,1);
            //Toast.makeText(mContext, "Enter your objective", Toast.LENGTH_SHORT).show();
        } else {
            callObjectiveAPI();
            //closeActivity();
        }

    }

    private void callObjectiveAPI() {
        try {
            LoadingSpinner(mContext);
            dialogProgress.show();
            MSG = "callObjectiveAPI\t";
            HashMap<String, String> params = new HashMap<>();

            params.put("user_id", sessionManager.getUserDetail().getEmployee_id());
            params.put("objective", getETValue(binding.etObject));


            Call<ResponseBody> call = apiService.objectiveAdd(params);
            Log.d(TAG, MSG + "params\t\t" + params);


            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        if (response.isSuccessful()) {
                            dialogProgress.dismiss();
                            String responseRecieved = response.body().string();

                            Log.d(TAG, MSG + "responseRecieved\t\t" + responseRecieved);
                            JSONObject jsonObjectResult = new JSONObject(responseRecieved);
                            if (jsonObjectResult.getBoolean("status")) {
                                customToast("Successfully Added",0,3);
                                closeActivity();
                            } else {
                                customToast(jsonObjectResult.getString("message"),200,2);

                            }
                        }

                    } catch (Exception e) {
                        Log.e(TAG, MSG + "Exception \t" + e.getMessage());
                        dialogProgress.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.e(TAG, MSG + "ONFailure \t" + t.getMessage());
                    dialogProgress.dismiss();
                }
            });


        } catch (Exception e) {
            Log.d(TAG, MSG + ": Exception\t\t" + e);
            dialogProgress.dismiss();
        }
    }


    private void initValues() {
        mContext = this;
        sessionManager = new SessionManager(mContext);
        binding.tvWelcome.setText("Hello " + sessionManager.getUserDetail().getName());
    }
}