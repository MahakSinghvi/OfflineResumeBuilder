package com.ps.resumebuilder.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;

import com.ps.resumebuilder.DTO.CreateDashboardDTO;
import com.ps.resumebuilder.R;
import com.ps.resumebuilder.adapter.CreateDashboardAdapter;
import com.ps.resumebuilder.common.RbBaseActivity;
import com.ps.resumebuilder.databinding.ActivityCreateBinding;

import java.util.ArrayList;

public class CreateActivity extends RbBaseActivity {
    private String TAG = "CreateActivity";
    Context mContext;
    ActivityCreateBinding binding;
    CreateDashboardAdapter adapter;
    ArrayList<CreateDashboardDTO> createDashboardDTOArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_create);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_create);
        initValues();
        setMyRecycle();
        setArrayValues();
        clickEvents();
    }

    private void clickEvents() {
        binding.iconback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                finish();
//                exitActivityAnimation();
                closeActivity();
            }
        });
    }

    private void setArrayValues() {
        createDashboardDTOArrayList.clear();
        CreateDashboardDTO createDashboardDTO = new CreateDashboardDTO("Personal Details", R.drawable.img_ca1);
        CreateDashboardDTO createDashboardDTO1 = new CreateDashboardDTO("Career Objective", R.drawable.img_ca2);
        CreateDashboardDTO createDashboardDTO2 = new CreateDashboardDTO("Education Details", R.drawable.img_ca3);
        CreateDashboardDTO createDashboardDTO3 = new CreateDashboardDTO("Work Experince", R.drawable.img_ca5);
        CreateDashboardDTO createDashboardDTO4 = new CreateDashboardDTO("Projects", R.drawable.img_ca4);
        CreateDashboardDTO createDashboardDTO5 = new CreateDashboardDTO("Skills", R.drawable.img_ca6);
        createDashboardDTOArrayList.add(createDashboardDTO);
        createDashboardDTOArrayList.add(createDashboardDTO1);
        createDashboardDTOArrayList.add(createDashboardDTO2);
        createDashboardDTOArrayList.add(createDashboardDTO3);
        createDashboardDTOArrayList.add(createDashboardDTO4);
        createDashboardDTOArrayList.add(createDashboardDTO5);


    }

    private void setMyRecycle() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 2, GridLayoutManager.VERTICAL, false);
        adapter = new CreateDashboardAdapter(mContext, createDashboardDTOArrayList);
        binding.myrecyclecreate.setLayoutManager(gridLayoutManager);
        binding.myrecyclecreate.setAdapter(adapter);


    }

    private void initValues() {
        mContext = this;
        createDashboardDTOArrayList = new ArrayList<>();
    }

}